create table bank(
    -> id varchar(20),
    -> name varchar(20),
    -> age varchar(20),
    -> tel varchar(20)
    -> );