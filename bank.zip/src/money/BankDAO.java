package money;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class BankDAO {
	BankDTO dto = new BankDTO();
	String url = "jdbc:mysql://localhost:3306/bank";
	String user = "root";
	String password = "1234";
	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs;
	
	public void insert(BankDTO dto) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		String sql = "insert into bank values (?,?,?,?)";
				
		conn = DriverManager.getConnection(url,user,password);
		ps = conn.prepareStatement(sql);
		
		ps.setString(1, dto.getId());
		System.out.println(dto.getId());
		ps.setString(2, dto.getName());
		ps.setString(3, dto.getAge());
		ps.setString(4, dto.getTel());
		ps.executeUpdate();	
	}
	
	public void update(BankDTO dto) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String sql = "update bank set tel=? where id=?";
					
			conn = DriverManager.getConnection(url,user,password);
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, dto.getTel());
			ps.setString(2, dto.getId());
	        ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
					
	}
	
	public void delete(BankDTO dto) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		String sql = "delete from bank where id=?";
				
		conn = DriverManager.getConnection(url,user,password);
		ps = conn.prepareStatement(sql);
		
		ps.setString(1, dto.getId());
		ps.executeUpdate();				
	}
	
	public BankDTO select(String inputId) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String sql = "select * from bank where id=?";
			
			conn = DriverManager.getConnection(url,user,password);
			ps = conn.prepareStatement(sql);
			ps.setString(1,inputId);
			rs = ps.executeQuery();
			if(rs.next()) {
				dto = new BankDTO();
				String id = rs.getString(1);
				String name = rs.getString(2);
				String age = rs.getString(3);
				String tel = rs.getString(4);
				dto.setId(id);
				dto.setName(name);
				dto.setAge(age);
				dto.setTel(tel);
			} else {
				System.out.println("조회 오류");
			}
			
			ps.executeUpdate();	
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			} //catch
		}//finally
		return dto;
	}//calss
	
	public  ArrayList selectAll() {
		 ArrayList list = new ArrayList();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			String sql = "select * from bank";
			
			conn = DriverManager.getConnection(url,user,password);
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				dto = new BankDTO();
				
				String id = rs.getString(1);
				String name = rs.getString(2);
				String age = rs.getString(3);
				String tel = rs.getString(4);
				
				dto.setId(id);
				dto.setName(name);
				dto.setAge(age);
				dto.setTel(tel);
				
				 list.add(dto);
			}
			
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			} //catch
		}//finally
		return list;
	}//calss
}


