package money;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class BankManager {
	private JTextField idText;
	private JTextField nameText;
	private JTextField ageText;
	private JTextField telText;
	BankDTO dto = new BankDTO();
	
	public BankManager() {
		JFrame f = new JFrame("은행 고객 관리 프로그램");
		f.setSize(306, 432);
		FlowLayout flow = new FlowLayout();
		f.getContentPane().setLayout(flow);
		
		JLabel label = new JLabel("\uC544\uC774\uB514");
		label.setFont(new Font("Dialog", Font.BOLD, 20));
		f.getContentPane().add(label);
		
		idText = new JTextField();
		idText.setFont(new Font("Dialog", Font.PLAIN, 20));
		f.getContentPane().add(idText);
		idText.setColumns(10);
		
		JLabel label_1 = new JLabel("이   름");
		label_1.setFont(new Font("Dialog", Font.BOLD, 20));
		f.getContentPane().add(label_1);
		
		nameText = new JTextField();
		nameText.setFont(new Font("Dialog", Font.PLAIN, 20));
		nameText.setColumns(10);
		f.getContentPane().add(nameText);
		
		JLabel label_2 = new JLabel("나   이");
		label_2.setFont(new Font("Dialog", Font.BOLD, 20));
		f.getContentPane().add(label_2);
		
		ageText = new JTextField();
		ageText.setFont(new Font("Dialog", Font.PLAIN, 20));
		ageText.setColumns(10);
		f.getContentPane().add(ageText);
		
		JLabel label_3 = new JLabel("번   호");
		label_3.setFont(new Font("Dialog", Font.BOLD, 20));
		f.getContentPane().add(label_3);
		
		telText = new JTextField();
		telText.setFont(new Font("Dialog", Font.PLAIN, 20));
		telText.setColumns(10);
		f.getContentPane().add(telText);
		
		JButton insert_Button = new JButton("     삽입하기     ");
		insert_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BankDTO dto = new BankDTO();
				dto.setId(idText.getText());
				dto.setName(nameText.getText());
				dto.setAge(ageText.getText());
				dto.setTel(telText.getText());
				BankDAO dao = new BankDAO();
				try {
					dao.insert(dto);
					JOptionPane.showMessageDialog(null, "삽입완료");
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		insert_Button.setFont(new Font("Dialog", Font.PLAIN, 20));
		f.getContentPane().add(insert_Button);
		
		JButton delete_Button = new JButton("     삭제하기     ");
		delete_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BankDTO dto = new BankDTO();
				dto.setId(idText.getText());
				BankDAO dao = new BankDAO();
				try {
					dao.delete(dto);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		delete_Button.setFont(new Font("Dialog", Font.PLAIN, 20));
		f.getContentPane().add(delete_Button);
		
		JButton update_Button = new JButton("     변경하기     ");
		update_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BankDTO dto = new BankDTO();
				dto.setId(idText.getText());
				dto.setTel(telText.getText());
				BankDAO dao = new BankDAO();
				try {
					dao.update(dto);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		update_Button.setFont(new Font("Dialog", Font.PLAIN, 20));
		f.getContentPane().add(update_Button);
		
		JButton select_Button = new JButton("     검색하기     ");
		select_Button.setFont(new Font("Dialog", Font.PLAIN, 20));
		select_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String inputId = idText.getText();
				BankDAO dao = new BankDAO();
				BankDTO dto = dao.select(inputId);
				String id = dto.getId();
				String name = dto.getName();
				String age = dto.getAge();
				String tel = dto.getTel();
				idText.setText(id);
				nameText.setText(name);
				ageText.setText(age);
				telText.setText(tel);
			}
		});
		f.getContentPane().add(select_Button);
		
		JButton selectAll_Button = new JButton("  전체검색하기  ");
		selectAll_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	            BankDAO dao = new BankDAO();
	            ArrayList list = dao.selectAll();
				
	            System.out.println("순번    id    name    age    tel");
				for (int i = 0; i < list.size(); i++) {
					BankDTO dto = (BankDTO)list.get(i);
					System.out.print((i+1)+"번 : ");
	                System.out.print(dto.getId()+"  ");
	                System.out.print("     "+dto.getName()+" ");
	                System.out.print("     "+dto.getAge()+" ");
	                System.out.print("     "+dto.getTel()+" ");
	                System.out.println();
				}
				
				try {
					dao.selectAll();
					JOptionPane.showMessageDialog(null, "검색완료");
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		selectAll_Button.setFont(new Font("Dialog", Font.PLAIN, 20));
		f.getContentPane().add(selectAll_Button);
		
			
		f.setVisible(true);
	}
	
	public static void main(String[] args) {
		BankManager name = new BankManager();
	}
}
